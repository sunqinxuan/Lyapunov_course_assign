% ==========================
% Author: Sun Qinxuan
% Last modified: Apr.16,2017
% Filename: assign2_a_sqx.m
% Description: EMK control.
% ==========================
clear all;clc;
close all;
options=odeset('reltol',1e-7);
last_time=15;
x0=[2;1];
k=1;
ku=1;

% [t_sys,y_sys]=ode45(@sys_model,[0,last_time],x0,options);
[t_ctl,y_ctl]=ode45(@back_stepping,[0,last_time],x0,options,k,ku);

% t_dsr=0:0.001:last_time;
y_dsr=10*sin(t_ctl);
for n=1:size(t_ctl,1)
    u_ctl(n,1)=controller(t_ctl(n),y_ctl(n,:),k,ku);
end
ctl_error=y_dsr-y_ctl(:,1);
% for n=1:size(ctl_error,1)
%     if abs(ctl_error(n))<0.001
%         t_ctl(n)
%         break;
%     end
% end

figure;
% plot(t_ctl,y_dsr,'k--');hold on;
plot(t_ctl,y_ctl(:,1),'g--');hold on;
% plot(t_ctl,ctl_error,'r-');hold on;
plot(t_ctl,u_ctl,'b--');hold on;
% plot(t_ctl,r,'k.-');hold on;
title('Back-stepping');
xlabel('t');
legend('x','u');
% axis([0 0.5 -1 1]);